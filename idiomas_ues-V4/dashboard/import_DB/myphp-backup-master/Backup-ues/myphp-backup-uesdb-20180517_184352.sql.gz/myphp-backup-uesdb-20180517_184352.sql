CREATE DATABASE IF NOT EXISTS `uesdb`;

USE `uesdb`;

SET FOREIGN_KEY_CHECKS=false;

DROP TABLE IF EXISTS `archivoxpost`;

CREATE TABLE `archivoxpost` (
  `archivoXPostId` int(11) NOT NULL AUTO_INCREMENT,
  `postId` int(11) NOT NULL,
  `nombreArchivo` varchar(50) NOT NULL,
  `urlArhivo` varchar(100) NOT NULL,
  PRIMARY KEY (`archivoXPostId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `asignatura`;

CREATE TABLE `asignatura` (
  `asignaturaId` int(11) NOT NULL AUTO_INCREMENT,
  `asignatura` varchar(50) NOT NULL,
  `cicloId` int(11) NOT NULL,
  `estadoId` int(11) NOT NULL,
  PRIMARY KEY (`asignaturaId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

INSERT INTO `asignatura` VALUES("1","Métodos de Estudio a Distancia e Investigación","1","1");
INSERT INTO `asignatura` VALUES("2","Sociología de la Educación","1","1");
INSERT INTO `asignatura` VALUES("3","Psicología del Niño en Edad Escolar","1","1");
INSERT INTO `asignatura` VALUES("4","Instituciones Educativas: Teorías y Concepciones","1","1");
INSERT INTO `asignatura` VALUES("5","Conversación Inglesa I","2","1");
INSERT INTO `asignatura` VALUES("6","Gramática Inglesa I","2","1");
INSERT INTO `asignatura` VALUES("7","Fonética Inglesa I","2","1");
INSERT INTO `asignatura` VALUES("8","Planeamiento Didáctico","2","1");



DROP TABLE IF EXISTS `aspirante`;

CREATE TABLE `aspirante` (
  `aspiranteId` int(11) NOT NULL AUTO_INCREMENT,
  `nombresAspirante` varchar(50) NOT NULL,
  `apellidosAspirante` varchar(50) NOT NULL,
  `correoAspirante` varchar(50) NOT NULL,
  `telefonoAspirante` varchar(50) NOT NULL,
  `fotoAspirante` varchar(50) NOT NULL,
  `DUIAspirante` varchar(9) NOT NULL,
  `CVAspirante` varchar(50) NOT NULL,
  `estadoId` int(11) NOT NULL,
  PRIMARY KEY (`aspiranteId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `ciclo`;

CREATE TABLE `ciclo` (
  `cicloId` int(11) NOT NULL AUTO_INCREMENT,
  `ciclo` varchar(10) NOT NULL,
  PRIMARY KEY (`cicloId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

INSERT INTO `ciclo` VALUES("1","I");
INSERT INTO `ciclo` VALUES("2","II");
INSERT INTO `ciclo` VALUES("3","III");
INSERT INTO `ciclo` VALUES("4","IV");
INSERT INTO `ciclo` VALUES("5","V");
INSERT INTO `ciclo` VALUES("6","VI");
INSERT INTO `ciclo` VALUES("7","VII");
INSERT INTO `ciclo` VALUES("8","VIII");
INSERT INTO `ciclo` VALUES("9","IX");
INSERT INTO `ciclo` VALUES("10","X");



DROP TABLE IF EXISTS `estado`;

CREATE TABLE `estado` (
  `estadoId` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(10) NOT NULL,
  `tipoEstadoId` int(11) NOT NULL,
  PRIMARY KEY (`estadoId`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

INSERT INTO `estado` VALUES("1","Activo","1");
INSERT INTO `estado` VALUES("2","Inactivo","1");
INSERT INTO `estado` VALUES("3","Recibido","2");
INSERT INTO `estado` VALUES("4","En Revisió","2");
INSERT INTO `estado` VALUES("5","Procesado","2");
INSERT INTO `estado` VALUES("6","Anulado","2");
INSERT INTO `estado` VALUES("7","A Iniciar","3");
INSERT INTO `estado` VALUES("8","En Desarol","3");
INSERT INTO `estado` VALUES("9","Finalizado","3");
INSERT INTO `estado` VALUES("10","Anulado","3");
INSERT INTO `estado` VALUES("11","Pre-Inscri","4");
INSERT INTO `estado` VALUES("12","Inscrito","4");
INSERT INTO `estado` VALUES("13","Anulado","4");
INSERT INTO `estado` VALUES("14","Pendiente","5");
INSERT INTO `estado` VALUES("15","Realizada","5");
INSERT INTO `estado` VALUES("16","Anulada","5");



DROP TABLE IF EXISTS `evaluacion`;

CREATE TABLE `evaluacion` (
  `evaluacionId` int(11) NOT NULL AUTO_INCREMENT,
  `nombreEvaluacion` varchar(50) NOT NULL,
  `tipoEvaluacionId` int(11) NOT NULL,
  `tutoriaId` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `horaEvaluacion` time NOT NULL,
  `estadoId` int(11) NOT NULL,
  PRIMARY KEY (`evaluacionId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `mensajeria`;

CREATE TABLE `mensajeria` (
  `mensajeriaId` int(11) NOT NULL AUTO_INCREMENT,
  `usuarioIdRemitente` int(11) NOT NULL,
  `usuarioIdDetinatario` int(11) NOT NULL,
  `mensaje` varchar(100) NOT NULL,
  `fechaMensajeria` date NOT NULL,
  `horaMensajeria` time NOT NULL,
  PRIMARY KEY (`mensajeriaId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `postId` int(11) NOT NULL AUTO_INCREMENT,
  `tituloPost` varchar(50) NOT NULL,
  `post` varchar(1000) NOT NULL,
  `tipoPostId` int(11) NOT NULL,
  `tutoriaId` int(11) NOT NULL,
  `fechaPost` date NOT NULL,
  `horaPost` time NOT NULL,
  `estadoId` int(11) NOT NULL,
  PRIMARY KEY (`postId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `sede`;

CREATE TABLE `sede` (
  `sedeId` int(11) NOT NULL AUTO_INCREMENT,
  `sede` varchar(50) NOT NULL,
  `estadoId` int(11) NOT NULL,
  PRIMARY KEY (`sedeId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `sede` VALUES("1","San Salvador","1");
INSERT INTO `sede` VALUES("2","Santa Tecla","1");
INSERT INTO `sede` VALUES("3","Santa Ana","1");
INSERT INTO `sede` VALUES("4","San Vicente","1");
INSERT INTO `sede` VALUES("5","San Miguel","1");
INSERT INTO `sede` VALUES("6","Virtual","1");



DROP TABLE IF EXISTS `tipoestado`;

CREATE TABLE `tipoestado` (
  `tipoEstadoId` int(11) NOT NULL AUTO_INCREMENT,
  `tipoEstado` varchar(10) NOT NULL,
  PRIMARY KEY (`tipoEstadoId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tipoestado` VALUES("1","Mantenimie");
INSERT INTO `tipoestado` VALUES("2","Aspirante");
INSERT INTO `tipoestado` VALUES("3","Tutoria");
INSERT INTO `tipoestado` VALUES("4","TutoriaXEs");
INSERT INTO `tipoestado` VALUES("5","Evaluación");



DROP TABLE IF EXISTS `tipoevaluacion`;

CREATE TABLE `tipoevaluacion` (
  `tipoEvaluacionId` int(11) NOT NULL AUTO_INCREMENT,
  `tipoEvaluacion` varchar(10) NOT NULL,
  PRIMARY KEY (`tipoEvaluacionId`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `tipoevaluacion` VALUES("1","Parcial");
INSERT INTO `tipoevaluacion` VALUES("2","Práctica");
INSERT INTO `tipoevaluacion` VALUES("3","Laboratori");
INSERT INTO `tipoevaluacion` VALUES("4","Avance");
INSERT INTO `tipoevaluacion` VALUES("5","Control de");
INSERT INTO `tipoevaluacion` VALUES("6","Trabajo");
INSERT INTO `tipoevaluacion` VALUES("7","Tarea Ex-A");



DROP TABLE IF EXISTS `tipopost`;

CREATE TABLE `tipopost` (
  `tipoPostId` int(11) NOT NULL AUTO_INCREMENT,
  `tipoPost` varchar(10) NOT NULL,
  PRIMARY KEY (`tipoPostId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tipopost` VALUES("1","Informativ");
INSERT INTO `tipopost` VALUES("2","Notificaci");
INSERT INTO `tipopost` VALUES("3","Aviso");



DROP TABLE IF EXISTS `tipotutoria`;

CREATE TABLE `tipotutoria` (
  `tipoTutoriaId` int(11) NOT NULL AUTO_INCREMENT,
  `tipoTutoria` varchar(10) NOT NULL,
  PRIMARY KEY (`tipoTutoriaId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tipotutoria` VALUES("1","Presencial");
INSERT INTO `tipotutoria` VALUES("2","Virtual");



DROP TABLE IF EXISTS `tipousuario`;

CREATE TABLE `tipousuario` (
  `tipoUsuarioId` int(11) NOT NULL AUTO_INCREMENT,
  `tipoUsuario` varchar(10) NOT NULL,
  PRIMARY KEY (`tipoUsuarioId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tipousuario` VALUES("1","Coordinado");
INSERT INTO `tipousuario` VALUES("2","Coordinado");
INSERT INTO `tipousuario` VALUES("3","Tutor Cont");
INSERT INTO `tipousuario` VALUES("4","Tutor Doce");
INSERT INTO `tipousuario` VALUES("5","Estudiante");



DROP TABLE IF EXISTS `tutoria`;

CREATE TABLE `tutoria` (
  `tutoriaId` int(11) NOT NULL AUTO_INCREMENT,
  `asignaturaId` int(11) NOT NULL,
  `usuarioId` int(11) NOT NULL,
  `diaTutoria` varchar(6) NOT NULL,
  `horaInicioTutoria` time NOT NULL,
  `horaFinTutoria` time NOT NULL,
  `fechaInicioTutoria` date NOT NULL,
  `fechaFinTutoria` date NOT NULL,
  `sedeId` int(11) NOT NULL,
  `tipoTutoriaId` int(11) NOT NULL,
  `estadoId` int(11) NOT NULL,
  PRIMARY KEY (`tutoriaId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tutoria` VALUES("1","1","3","Lunes","10:00:00","12:00:00","2018-05-15","2018-12-21","1","1","8");
INSERT INTO `tutoria` VALUES("2","2","4","Martes","07:00:00","09:00:00","2018-01-15","2018-06-15","2","1","8");



DROP TABLE IF EXISTS `tutoriaxestudiante`;

CREATE TABLE `tutoriaxestudiante` (
  `tutoriaXEstudianteId` int(11) NOT NULL AUTO_INCREMENT,
  `tutoriaId` int(11) NOT NULL,
  `usuarioId` int(11) NOT NULL,
  `estadoId` int(11) NOT NULL,
  PRIMARY KEY (`tutoriaXEstudianteId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE IF EXISTS `usuario`;

CREATE TABLE `usuario` (
  `usuarioId` int(11) NOT NULL AUTO_INCREMENT,
  `nombresUsuario` varchar(50) NOT NULL,
  `apellidosUsurio` varchar(50) NOT NULL,
  `correoUsuario` varchar(50) NOT NULL,
  `contrasenaUsuario` varchar(100) NOT NULL,
  `telefonoUsuario` varchar(50) NOT NULL,
  `fotoUsuario` varchar(50) DEFAULT NULL,
  `DUIUsuario` varchar(9) NOT NULL,
  `CVEmpleado` varchar(50) DEFAULT NULL,
  `DUEstudiante` varchar(7) NOT NULL,
  `sedeId` int(11) NOT NULL,
  `tipoUsuarioId` int(11) NOT NULL,
  `estadoId` int(11) NOT NULL,
  PRIMARY KEY (`usuarioId`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `usuario` VALUES("1","Kevin Leonardo","Henríquez Martínez","kevin.henriquez@ues.edu.sv","0000","2222-2222 / 7777-7777","RUTA","201602650","RUTA","NULL","1","1","1");
INSERT INTO `usuario` VALUES("2","Alexandra Marina","Castillo Méndez","alexandra.castillo@ues.edu.sv","0000","2222-2222 / 7777-7777","RUTA","201600920","RUTA","NULL","1","2","1");
INSERT INTO `usuario` VALUES("3","Eduardo Josué","García Ortíz","eduardo.garcia@ues.edu.sv","0000","2222-2222 / 7777-7777","RUTA","201402030","RUTA","NULL","2","3","1");
INSERT INTO `usuario` VALUES("4","Luis Roberto","Nerio Rivas","luis.nerio@ues.edu.sv","0000","2222-2222 / 7777-7777","RUTA","201401870","RUTA","NULL","3","4","1");
INSERT INTO `usuario` VALUES("5","Geovany Fernando","Godinez López","geovany.godinez@ues.edu.sv","0000","2222-2222 / 7777-7777","RUTA","201602460","NULL","2014GL1","4","5","1");
